package option; 

import option.GuiFrame;

public class main {
    public static void main(String arg[]) {
    	GuiFrame a = new GuiFrame();
    	a.setVisible(true);
    	a.setLocationRelativeTo(null);
    }
}
